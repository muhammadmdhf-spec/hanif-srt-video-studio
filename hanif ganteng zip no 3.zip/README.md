# Editor Subtitle (Android native, Tahap 1)

Aplikasi Android native (Kotlin + Jetpack Compose + Media3). Berjalan 100% offline setelah diinstal.
APK dibangun otomatis oleh GitHub Actions, jadi tidak perlu laptop.

## Fitur Tahap 1
- Pilih video dari galeri (MP4, WebM, MOV) dan preview dengan ExoPlayer.
- Muat 2 file SRT (Arab dan Inggris/Indonesia) atau tempel manual.
- Tampilkan Arab saja, Inggris saja, atau keduanya.
- Gaya: font, bobot (Regular/Medium/Bold), ukuran, warna teks, warna dan tebal outline, posisi vertikal, rata kiri/tengah/kanan.
- Ekspor MP4 dengan subtitle menyatu (Media3 Transformer) + progress bar.
- Ekspor SRT (Arab dan Inggris terpisah).
- Pengaturan tersimpan otomatis + tombol Reset ke Default.

Tahap 2 (sudah ada): kotak latar (15 tema, 9 bentuk, gradient, geser, ukuran) dan 15 tema warna subtitle. Tahap 3 (sudah ada): geser tiap baris subtitle di preview dan efek kata dinamis (kata tertentu lebih besar dan berwarna).

## Cara upload ke GitHub (dari HP, tanpa laptop)
1. Buka github.com di browser HP, login, lalu buat repositori baru (New repository), misalnya `subtitle-editor`. Boleh Private.
2. Di halaman repositori: **Add file > Upload files**, pilih file **`project.zip`** (jangan diekstrak), lalu **Commit changes**.
3. **Add file > Create new file**. Pada kolom nama ketik persis:
   `.github/workflows/android-build.yml`
   (saat mengetik tanda `/`, GitHub otomatis membuat folder). Tempel isi file `android-build.yml`, lalu **Commit changes**.

Catatan: workflow akan mengekstrak `project.zip` sendiri di server GitHub, jadi struktur folder tidak perlu dibuat manual.

## Menjalankan GitHub Actions
- Setiap commit ke branch `main` otomatis memulai build.
- Manual: tab **Actions > Build Android APK > Run workflow**.
- Build pertama sekitar 8-15 menit (mengunduh Android SDK, library, dan font).
- Buka run yang berjalan, lihat langkah **Unduh font dari Google Fonts**: baris `GAGAL` berarti font itu dilewati (aplikasi tetap jalan).

## Download dan install APK
1. Setelah build hijau, buka run tersebut, gulir ke bawah ke **Artifacts**, ketuk **SubtitleEditor-debug-apk** (file ZIP).
2. Ekstrak ZIP dengan aplikasi File/Files bawaan HP, ambil `app-debug.apk`.
3. Ketuk APK, izinkan "Install dari sumber tidak dikenal" untuk browser/file manager, lalu Install.

## Cara pakai
Pilih video, muat SRT, atur gaya di preview, ketuk **Download MP4**. Tunggu render selesai (jangan tutup aplikasi), lalu pilih lokasi simpan.

## Catatan teknis
- Subtitle digambar dengan Canvas Android (StaticLayout), sehingga huruf Arab tersambung dan arah RTL benar. Kode yang sama dipakai untuk preview dan ekspor.
- Helvetica/Helvetica Neue/DecoType Naskh berlisensi berbayar; diganti Arimo dan Noto Naskh Arabic.
- Versi: AGP 8.10.1, Kotlin 2.1.21, Compose BOM 2025.05.01, Media3 1.6.1, Gradle 8.11.1, JDK 17, compileSdk/targetSdk 36, minSdk 26.
