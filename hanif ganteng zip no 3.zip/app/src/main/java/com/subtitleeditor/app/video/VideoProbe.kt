package com.subtitleeditor.app.video

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri

/** Ukuran video SETELAH rotasi diterapkan (ukuran yang tampil di layar). */
data class VideoInfo(val width: Int, val height: Int, val durationMs: Long)

object VideoProbe {
    fun probe(context: Context, uri: Uri): VideoInfo? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (w == null || h == null || w <= 0 || h <= 0) {
                null
            } else if (rot == 90 || rot == 270) {
                VideoInfo(h, w, dur)
            } else {
                VideoInfo(w, h, dur)
            }
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }
}
