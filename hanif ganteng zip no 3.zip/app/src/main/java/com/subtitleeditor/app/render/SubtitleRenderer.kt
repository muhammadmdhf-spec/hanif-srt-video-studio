package com.subtitleeditor.app.render

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import com.subtitleeditor.app.style.BoxShape
import com.subtitleeditor.app.style.LineOffset
import com.subtitleeditor.app.style.SubtitleStyle
import com.subtitleeditor.app.style.TextAlignMode

/**
 * Menggambar kotak latar + subtitle ke Bitmap transparan seukuran frame video.
 * Kode yang SAMA dipakai untuk preview dan ekspor MP4 (hasil identik).
 * StaticLayout milik Android menangani shaping huruf Arab dan arah RTL secara otomatis.
 */
/** Batas satu blok teks dalam pecahan (0..1) dari lebar/tinggi frame. track: 0 = Arab, 1 = Inggris. */
data class BlockBounds(val track: Int, val l: Float, val t: Float, val r: Float, val b: Float)

class RenderResult(val bitmap: Bitmap, val blocks: List<BlockBounds>)

object SubtitleRenderer {

    private class Block(
        val fillLayout: StaticLayout,
        val strokeLayout: StaticLayout,
        val outlinePx: Float,
        val track: Int,
        val dx: Float,
        val dy: Float
    )

    fun render(
        width: Int,
        height: Int,
        style: SubtitleStyle,
        arabicTf: Typeface,
        latinTf: Typeface,
        arabicText: String?,
        latinText: String?,
        arabicOff: LineOffset = LineOffset(),
        latinOff: LineOffset = LineOffset()
    ): Bitmap = renderWithBounds(width, height, style, arabicTf, latinTf, arabicText, latinText, arabicOff, latinOff).bitmap

    fun renderWithBounds(
        width: Int,
        height: Int,
        style: SubtitleStyle,
        arabicTf: Typeface,
        latinTf: Typeface,
        arabicText: String?,
        latinText: String?,
        arabicOff: LineOffset = LineOffset(),
        latinOff: LineOffset = LineOffset()
    ): RenderResult {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val base = minOf(width, height).toFloat()
        val margin = base * 0.05f
        val avail = (width - 2 * margin).toInt().coerceAtLeast(50)

        val blocks = ArrayList<Block>()
        if (!arabicText.isNullOrBlank()) {
            blocks.add(
                makeBlock(
                    arabicText.trim(), arabicTf, base * style.arabicSizePct / 100f, style.arabicColor,
                    style, avail, 0, width * arabicOff.dx / 100f, height * arabicOff.dy / 100f
                )
            )
        }
        if (!latinText.isNullOrBlank()) {
            blocks.add(
                makeBlock(
                    latinText.trim(), latinTf, base * style.latinSizePct / 100f, style.latinColor,
                    style, avail, 1, width * latinOff.dx / 100f, height * latinOff.dy / 100f
                )
            )
        }
        if (blocks.isEmpty()) return RenderResult(bmp, emptyList())

        val gap = base * 0.015f
        var total = gap * (blocks.size - 1)
        for (b in blocks) total += b.fillLayout.height
        val free = (height - 2 * margin - total).coerceAtLeast(0f)
        val startY = margin + free * (style.positionPct / 100f)

        // Posisi tiap blok, batas per blok (untuk geser), dan batas gabungan (untuk kotak latar)
        val ys = FloatArray(blocks.size)
        val bounds = ArrayList<BlockBounds>()
        var y = startY
        var minL = Float.MAX_VALUE
        var maxR = 0f
        var minT = Float.MAX_VALUE
        var maxB = 0f
        for (i in blocks.indices) {
            val bk = blocks[i]
            val lay = bk.fillLayout
            ys[i] = y
            var bl = Float.MAX_VALUE
            var br = 0f
            for (li in 0 until lay.lineCount) {
                bl = minOf(bl, lay.getLineLeft(li))
                br = maxOf(br, lay.getLineRight(li))
            }
            if (bl > br) {
                bl = 0f
                br = avail.toFloat()
            }
            val absL = margin + bk.dx + bl
            val absR = margin + bk.dx + br
            val top = y + bk.dy
            val bottom = top + lay.height
            minL = minOf(minL, absL)
            maxR = maxOf(maxR, absR)
            minT = minOf(minT, top)
            maxB = maxOf(maxB, bottom)
            bounds.add(BlockBounds(bk.track, absL / width, top / height, absR / width, bottom / height))
            y += lay.height + gap
        }

        if (style.boxEnabled) {
            drawBox(canvas, style, RectF(minL, minT, maxR, maxB), width, height, base)
        }

        for (i in blocks.indices) {
            val b = blocks[i]
            canvas.save()
            canvas.translate(margin + b.dx, ys[i] + b.dy)
            if (b.outlinePx > 0f) b.strokeLayout.draw(canvas)
            b.fillLayout.draw(canvas)
            canvas.restore()
        }
        return RenderResult(bmp, bounds)
    }

    private fun newPaint(tf: Typeface, sizePx: Float, colorInt: Int): TextPaint {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = sizePx.coerceAtLeast(4f)
        p.typeface = tf
        p.color = colorInt
        return p
    }

    private fun buildLayout(
        cs: CharSequence,
        paint: TextPaint,
        avail: Int,
        alignment: Layout.Alignment
    ): StaticLayout =
        StaticLayout.Builder.obtain(cs, 0, cs.length, paint, avail)
            .setAlignment(alignment)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.15f)
            .build()

    private fun makeBlock(
        text: String,
        tf: Typeface,
        sizePx: Float,
        fill: Int,
        style: SubtitleStyle,
        avail: Int,
        track: Int,
        dx: Float,
        dy: Float
    ): Block {
        val rtl = TextDirectionHeuristics.FIRSTSTRONG_LTR.isRtl(text, 0, text.length)
        val alignment = when (style.align) {
            TextAlignMode.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignMode.LEFT -> if (rtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
            TextAlignMode.RIGHT -> if (rtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
        }

        // Efek kata dinamis: kata tertentu lebih besar dan berwarna khusus.
        // Layout outline hanya memakai span ukuran, layout isi memakai ukuran + warna.
        val sizeText = SpannableStringBuilder(text)
        val fullText = SpannableStringBuilder(text)
        val words = style.highlightWord.split(',', '\u060C', '\n').map { it.trim() }.filter { it.isNotEmpty() }
        if (words.isNotEmpty()) {
            val covered = BooleanArray(text.length)
            for (w in words) {
                val regex = Regex(Regex.escape(w), RegexOption.IGNORE_CASE)
                for (m in regex.findAll(text)) {
                    val s = m.range.first
                    val e = m.range.last + 1
                    if (e > text.length || s >= e) continue
                    var overlap = false
                    for (k in s until e) if (covered[k]) overlap = true
                    if (overlap) continue
                    for (k in s until e) covered[k] = true
                    if (style.highlightScale != 1f) {
                        sizeText.setSpan(RelativeSizeSpan(style.highlightScale), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        fullText.setSpan(RelativeSizeSpan(style.highlightScale), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    fullText.setSpan(ForegroundColorSpan(style.highlightColor), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }

        val fillPaint = newPaint(tf, sizePx, fill)
        val outlinePx = sizePx * style.outlineWidth * 0.03f
        val strokePaint = newPaint(tf, sizePx, style.outlineColor)
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeWidth = outlinePx
        strokePaint.strokeJoin = Paint.Join.ROUND

        return Block(
            fillLayout = buildLayout(fullText, fillPaint, avail, alignment),
            strokeLayout = buildLayout(sizeText, strokePaint, avail, alignment),
            outlinePx = outlinePx,
            track = track,
            dx = dx,
            dy = dy
        )
    }

    // ---------------------------------------------------------------- Kotak latar

    private fun withOpacity(color: Int, opacity: Float): Int {
        val a = (android.graphics.Color.alpha(color) * opacity.coerceIn(0f, 1f)).toInt()
        return (color and 0x00FFFFFF) or (a shl 24)
    }

    private fun drawBox(canvas: Canvas, style: SubtitleStyle, content: RectF, w: Int, h: Int, base: Float) {
        val pad = base * style.boxPadding / 100f
        var l = content.left - pad
        val t = content.top - pad * 0.7f
        var r = content.right + pad
        val b = content.bottom + pad * 0.7f
        when (style.boxShape) {
            BoxShape.BANNER -> {
                l = 0f
                r = w.toFloat()
            }
            BoxShape.RIBBON -> {
                l -= pad * 2.5f
                r += pad * 2.5f
            }
            else -> Unit
        }
        val cx = (l + r) / 2f
        val cy = (t + b) / 2f
        val hw = (r - l) / 2f * style.boxScaleW
        val hh = (b - t) / 2f * style.boxScaleH
        val dx = w * style.boxOffsetX / 100f
        val dy = h * style.boxOffsetY / 100f
        val rect = RectF(cx - hw + dx, cy - hh + dy, cx + hw + dx, cy + hh + dy)

        val path = buildShape(style.boxShape, rect, base)
        val rotation = when (style.boxShape) {
            BoxShape.STAMP -> -3f
            BoxShape.TAPE -> -2f
            else -> 0f
        }

        canvas.save()
        if (rotation != 0f) canvas.rotate(rotation, rect.centerX(), rect.centerY())

        if (style.boxShadow) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.style = Paint.Style.FILL
            sp.color = 0xAA000000.toInt()
            sp.maskFilter = BlurMaskFilter(base * 0.012f, BlurMaskFilter.Blur.NORMAL)
            canvas.save()
            canvas.translate(0f, base * 0.008f)
            canvas.drawPath(path, sp)
            canvas.restore()
        }

        if (style.boxOpacity > 0.001f) {
            val fp = Paint(Paint.ANTI_ALIAS_FLAG)
            fp.style = Paint.Style.FILL
            val c1 = withOpacity(style.boxColor1, style.boxOpacity)
            if (style.boxGradient) {
                val c2 = withOpacity(style.boxColor2, style.boxOpacity)
                fp.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, c1, c2, Shader.TileMode.CLAMP)
            } else {
                fp.color = c1
            }
            if (style.boxSoft) {
                fp.maskFilter = BlurMaskFilter(base * 0.01f, BlurMaskFilter.Blur.NORMAL)
            }
            canvas.drawPath(path, fp)
        }

        if (style.boxStrokeWidth > 0f) {
            val sw = base * style.boxStrokeWidth * 0.002f
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.style = Paint.Style.STROKE
            sp.strokeWidth = sw
            sp.strokeJoin = Paint.Join.ROUND
            sp.color = style.boxStrokeColor
            canvas.drawPath(path, sp)
            if (style.boxShape == BoxShape.STAMP) {
                val inner = RectF(rect)
                inner.inset(sw * 3f, sw * 3f)
                val ip = Path()
                ip.addRoundRect(inner, base * 0.005f, base * 0.005f, Path.Direction.CW)
                sp.strokeWidth = sw * 0.5f
                canvas.drawPath(ip, sp)
            }
        }
        canvas.restore()
    }

    private fun buildShape(shape: BoxShape, r: RectF, base: Float): Path {
        val p = Path()
        when (shape) {
            BoxShape.RECT, BoxShape.BANNER -> p.addRect(r, Path.Direction.CW)

            BoxShape.ROUNDED -> {
                val rad = base * 0.03f
                p.addRoundRect(r, rad, rad, Path.Direction.CW)
            }

            BoxShape.OVAL -> {
                val o = RectF(r)
                o.inset(-r.width() * 0.12f, -r.height() * 0.22f)
                p.addOval(o, Path.Direction.CW)
            }

            BoxShape.PILL -> {
                val rad = r.height() / 2f
                p.addRoundRect(r, rad, rad, Path.Direction.CW)
            }

            BoxShape.BUBBLE -> {
                val rad = base * 0.035f
                p.addRoundRect(r, rad, rad, Path.Direction.CW)
                val tail = Path()
                val x0 = r.left + r.width() * 0.2f
                val tw = base * 0.035f
                val th = base * 0.03f
                tail.moveTo(x0, r.bottom - 1f)
                tail.lineTo(x0 - tw * 0.3f, r.bottom + th)
                tail.lineTo(x0 + tw, r.bottom - 1f)
                tail.close()
                p.op(tail, Path.Op.UNION)
            }

            BoxShape.RIBBON -> {
                val n = r.height() * 0.35f
                val cy = r.centerY()
                p.moveTo(r.left, r.top)
                p.lineTo(r.right, r.top)
                p.lineTo(r.right - n, cy)
                p.lineTo(r.right, r.bottom)
                p.lineTo(r.left, r.bottom)
                p.lineTo(r.left + n, cy)
                p.close()
            }

            BoxShape.STAMP -> {
                val rad = base * 0.008f
                p.addRoundRect(r, rad, rad, Path.Direction.CW)
            }

            BoxShape.TAPE -> {
                val n = (r.height() / (base * 0.018f)).toInt().coerceAtLeast(3)
                val step = r.height() / n
                val d = base * 0.009f
                p.moveTo(r.left, r.top)
                p.lineTo(r.right, r.top)
                for (i in 0 until n) {
                    p.lineTo(r.right - d, r.top + step * (i + 0.5f))
                    p.lineTo(r.right, r.top + step * (i + 1))
                }
                p.lineTo(r.left, r.bottom)
                for (i in n - 1 downTo 0) {
                    p.lineTo(r.left + d, r.top + step * (i + 0.5f))
                    p.lineTo(r.left, r.top + step * i)
                }
                p.close()
            }
        }
        return p
    }
}
