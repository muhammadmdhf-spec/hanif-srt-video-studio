package com.subtitleeditor.app.style

import android.content.Context

enum class DisplayMode { ARABIC, LATIN, BOTH }

enum class TextAlignMode { LEFT, CENTER, RIGHT }

/** Pergeseran manual satu baris subtitle, dalam persen lebar/tinggi frame. */
data class LineOffset(val dx: Float = 0f, val dy: Float = 0f)

/**
 * Semua ukuran bersifat relatif terhadap sisi terpendek video (persen),
 * sehingga tampilan preview sama persis dengan hasil ekspor.
 * Bobot font: 0 = Regular, 1 = Medium, 2 = Bold.
 */
data class SubtitleStyle(
    val display: DisplayMode = DisplayMode.BOTH,
    val arabicFont: String = "Amiri",
    val latinFont: String = "Arimo",
    val arabicWeight: Int = 2,
    val latinWeight: Int = 2,
    val arabicSizePct: Float = 5.5f,
    val latinSizePct: Float = 4.5f,
    val arabicColor: Int = 0xFFFFFFFF.toInt(),
    val latinColor: Int = 0xFFFFFFFF.toInt(),
    val outlineColor: Int = 0xFF000000.toInt(),
    val outlineWidth: Float = 3f,
    val positionPct: Float = 85f,
    val align: TextAlignMode = TextAlignMode.CENTER,
    // ---- Kotak latar (Tahap 2) ----
    val boxEnabled: Boolean = false,
    val boxTheme: BoxTheme = BoxTheme.SOFT_BLACK,
    val boxShape: BoxShape = BoxShape.ROUNDED,
    val boxGradient: Boolean = false,
    val boxColor1: Int = 0xFF000000.toInt(),
    val boxColor2: Int = 0xFF000000.toInt(),
    val boxOpacity: Float = 0.6f,
    val boxPadding: Float = 2.5f,
    val boxScaleW: Float = 1f,
    val boxScaleH: Float = 1f,
    val boxOffsetX: Float = 0f,
    val boxOffsetY: Float = 0f,
    val boxStrokeWidth: Float = 0f,
    val boxStrokeColor: Int = 0xFFFFFFFF.toInt(),
    val boxShadow: Boolean = false,
    val boxSoft: Boolean = false,
    // ---- Efek kata dinamis (Tahap 3) ----
    val highlightWord: String = "",
    val highlightScale: Float = 1.5f,
    val highlightColor: Int = 0xFFFFEB3B.toInt()
)

class StyleStore(context: Context) {

    private val prefs = context.getSharedPreferences("subtitle_style", Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> enumOr(name: String?, default: T): T =
        try {
            if (name == null) default else enumValueOf<T>(name)
        } catch (e: Exception) {
            default
        }

    fun load(): SubtitleStyle {
        val d = SubtitleStyle()
        return SubtitleStyle(
            display = enumOr(prefs.getString("display", null), d.display),
            arabicFont = prefs.getString("arabicFont", d.arabicFont) ?: d.arabicFont,
            latinFont = prefs.getString("latinFont", d.latinFont) ?: d.latinFont,
            arabicWeight = prefs.getInt("arabicWeight", d.arabicWeight),
            latinWeight = prefs.getInt("latinWeight", d.latinWeight),
            arabicSizePct = prefs.getFloat("arabicSizePct", d.arabicSizePct),
            latinSizePct = prefs.getFloat("latinSizePct", d.latinSizePct),
            arabicColor = prefs.getInt("arabicColor", d.arabicColor),
            latinColor = prefs.getInt("latinColor", d.latinColor),
            outlineColor = prefs.getInt("outlineColor", d.outlineColor),
            outlineWidth = prefs.getFloat("outlineWidth", d.outlineWidth),
            positionPct = prefs.getFloat("positionPct", d.positionPct),
            align = enumOr(prefs.getString("align", null), d.align),
            boxEnabled = prefs.getBoolean("boxEnabled", d.boxEnabled),
            boxTheme = enumOr(prefs.getString("boxTheme", null), d.boxTheme),
            boxShape = enumOr(prefs.getString("boxShape", null), d.boxShape),
            boxGradient = prefs.getBoolean("boxGradient", d.boxGradient),
            boxColor1 = prefs.getInt("boxColor1", d.boxColor1),
            boxColor2 = prefs.getInt("boxColor2", d.boxColor2),
            boxOpacity = prefs.getFloat("boxOpacity", d.boxOpacity),
            boxPadding = prefs.getFloat("boxPadding", d.boxPadding),
            boxScaleW = prefs.getFloat("boxScaleW", d.boxScaleW),
            boxScaleH = prefs.getFloat("boxScaleH", d.boxScaleH),
            boxOffsetX = prefs.getFloat("boxOffsetX", d.boxOffsetX),
            boxOffsetY = prefs.getFloat("boxOffsetY", d.boxOffsetY),
            boxStrokeWidth = prefs.getFloat("boxStrokeWidth", d.boxStrokeWidth),
            boxStrokeColor = prefs.getInt("boxStrokeColor", d.boxStrokeColor),
            boxShadow = prefs.getBoolean("boxShadow", d.boxShadow),
            boxSoft = prefs.getBoolean("boxSoft", d.boxSoft),
            highlightWord = prefs.getString("highlightWord", d.highlightWord) ?: d.highlightWord,
            highlightScale = prefs.getFloat("highlightScale", d.highlightScale),
            highlightColor = prefs.getInt("highlightColor", d.highlightColor)
        )
    }

    fun save(s: SubtitleStyle) {
        prefs.edit()
            .putString("display", s.display.name)
            .putString("arabicFont", s.arabicFont)
            .putString("latinFont", s.latinFont)
            .putInt("arabicWeight", s.arabicWeight)
            .putInt("latinWeight", s.latinWeight)
            .putFloat("arabicSizePct", s.arabicSizePct)
            .putFloat("latinSizePct", s.latinSizePct)
            .putInt("arabicColor", s.arabicColor)
            .putInt("latinColor", s.latinColor)
            .putInt("outlineColor", s.outlineColor)
            .putFloat("outlineWidth", s.outlineWidth)
            .putFloat("positionPct", s.positionPct)
            .putString("align", s.align.name)
            .putBoolean("boxEnabled", s.boxEnabled)
            .putString("boxTheme", s.boxTheme.name)
            .putString("boxShape", s.boxShape.name)
            .putBoolean("boxGradient", s.boxGradient)
            .putInt("boxColor1", s.boxColor1)
            .putInt("boxColor2", s.boxColor2)
            .putFloat("boxOpacity", s.boxOpacity)
            .putFloat("boxPadding", s.boxPadding)
            .putFloat("boxScaleW", s.boxScaleW)
            .putFloat("boxScaleH", s.boxScaleH)
            .putFloat("boxOffsetX", s.boxOffsetX)
            .putFloat("boxOffsetY", s.boxOffsetY)
            .putFloat("boxStrokeWidth", s.boxStrokeWidth)
            .putInt("boxStrokeColor", s.boxStrokeColor)
            .putBoolean("boxShadow", s.boxShadow)
            .putBoolean("boxSoft", s.boxSoft)
            .putString("highlightWord", s.highlightWord)
            .putFloat("highlightScale", s.highlightScale)
            .putInt("highlightColor", s.highlightColor)
            .apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
