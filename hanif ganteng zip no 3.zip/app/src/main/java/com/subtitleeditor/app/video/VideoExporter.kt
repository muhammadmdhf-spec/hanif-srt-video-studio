package com.subtitleeditor.app.video

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

/** Menggabungkan video + subtitle menjadi MP4 memakai Media3 Transformer (harus dipanggil dari thread utama). */
@OptIn(UnstableApi::class)
class VideoExporter(private val context: Context) {

    sealed interface State {
        data object Idle : State
        data class Running(val percent: Int) : State
        data class Done(val file: File) : State
        data class Failed(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    fun start(scope: CoroutineScope, videoUri: Uri, overlay: SubtitleOverlay, outFile: File) {
        if (_state.value is State.Running) return
        outFile.parentFile?.mkdirs()
        if (outFile.exists()) outFile.delete()
        _state.value = State.Running(0)

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                progressJob?.cancel()
                transformer = null
                _state.value = State.Done(outFile)
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                progressJob?.cancel()
                transformer = null
                _state.value = State.Failed(
                    "Ekspor gagal (kode ${exportException.errorCode}): ${exportException.message ?: "tidak diketahui"}"
                )
            }
        }

        try {
            val t = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer = t

            val effects = Effects(
                emptyList(),
                listOf(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)))
            )
            val edited = EditedMediaItem.Builder(MediaItem.fromUri(videoUri))
                .setEffects(effects)
                .build()

            t.start(edited, outFile.absolutePath)

            progressJob = scope.launch {
                val holder = ProgressHolder()
                while (isActive) {
                    if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE &&
                        _state.value is State.Running
                    ) {
                        _state.value = State.Running(holder.progress)
                    }
                    delay(250)
                }
            }
        } catch (e: Exception) {
            transformer = null
            _state.value = State.Failed("Gagal memulai ekspor: ${e.message ?: "tidak diketahui"}")
        }
    }

    fun cancel() {
        progressJob?.cancel()
        try {
            transformer?.cancel()
        } catch (e: Exception) {
            // abaikan
        }
        transformer = null
        if (_state.value is State.Running) _state.value = State.Idle
    }

    fun reset() {
        if (_state.value !is State.Running) _state.value = State.Idle
    }
}
