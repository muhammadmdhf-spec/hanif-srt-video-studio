package com.subtitleeditor.app.ui

import androidx.annotation.OptIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.subtitleeditor.app.MainViewModel
import com.subtitleeditor.app.render.RenderResult
import com.subtitleeditor.app.render.SubtitleRenderer
import com.subtitleeditor.app.srt.SrtParser
import com.subtitleeditor.app.style.DisplayMode
import com.subtitleeditor.app.style.LineOffset
import com.subtitleeditor.app.video.VideoInfo
import kotlinx.coroutines.delay
import java.util.Locale

private const val SAMPLE_AR = "بسم الله الرحمن الرحيم"
private const val SAMPLE_EN = "In the name of God, the Most Gracious"

@Composable
fun PreviewPlayer(vm: MainViewModel) {
    val uri = vm.videoUri
    val info = vm.videoInfo
    if (uri == null || info == null) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Text("Belum ada video", color = Color.Gray)
        }
    } else {
        LoadedPlayer(vm, uri, info)
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun LoadedPlayer(vm: MainViewModel, uri: android.net.Uri, info: VideoInfo) {
    val context = LocalContext.current
    val exo = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { exo.release() } }

    LaunchedEffect(uri) {
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.repeatMode = Player.REPEAT_MODE_OFF
        exo.playWhenReady = false
        exo.prepare()
    }

    var positionMs by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var dragMode by remember { mutableStateOf(true) }
    LaunchedEffect(exo) {
        while (true) {
            positionMs = exo.currentPosition
            playing = exo.isPlaying
            delay(60)
        }
    }

    val style = vm.style
    val noCues = vm.arabicCues.isEmpty() && vm.latinCues.isEmpty()
    val showA = style.display != DisplayMode.LATIN
    val showL = style.display != DisplayMode.ARABIC

    val aText: String? = when {
        !showA -> null
        noCues -> SAMPLE_AR
        else -> SrtParser.activeText(vm.arabicCues, positionMs)
    }
    val lText: String? = when {
        !showL -> null
        noCues -> SAMPLE_EN
        else -> SrtParser.activeText(vm.latinCues, positionMs)
    }
    val aCue = if (showA && !noCues) SrtParser.activeCue(vm.arabicCues, positionMs) else null
    val lCue = if (showL && !noCues) SrtParser.activeCue(vm.latinCues, positionMs) else null
    val aOff = if (aCue != null) vm.arabicOffsets[aCue.index] ?: LineOffset() else LineOffset()
    val lOff = if (lCue != null) vm.latinOffsets[lCue.index] ?: LineOffset() else LineOffset()

    val aTf = remember(style.arabicFont, style.arabicWeight) {
        vm.fonts.typeface(style.arabicFont, style.arabicWeight)
    }
    val lTf = remember(style.latinFont, style.latinWeight) {
        vm.fonts.typeface(style.latinFont, style.latinWeight)
    }

    val pw = minOf(info.width, 720).coerceAtLeast(2)
    val ph = (pw.toLong() * info.height / info.width).toInt().coerceAtLeast(2)

    val rendered: RenderResult? = remember(aText, lText, style, pw, ph, aTf, lTf, aOff, lOff) {
        if (aText == null && lText == null) {
            null
        } else {
            SubtitleRenderer.renderWithBounds(pw, ph, style, aTf, lTf, aText, lText, aOff, lOff)
        }
    }
    val image = remember(rendered) { rendered?.bitmap?.asImageBitmap() }

    // Nilai terbaru untuk dipakai di dalam penanganan gestur
    val curRendered by rememberUpdatedState(rendered)
    val curStyle by rememberUpdatedState(style)
    val curACue by rememberUpdatedState(aCue)
    val curLCue by rememberUpdatedState(lCue)
    val curDragMode by rememberUpdatedState(dragMode)

    val ratio = info.width.toFloat() / info.height.toFloat()
    val duration = info.durationMs.toFloat().coerceAtLeast(1f)
    val hasOffsets = vm.arabicOffsets.isNotEmpty() || vm.latinOffsets.isNotEmpty()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .heightIn(max = 420.dp)
                    .aspectRatio(ratio)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            if (!curDragMode) return@awaitEachGesture
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            if (w <= 0f || h <= 0f) return@awaitEachGesture
                            val fx = down.position.x / w
                            val fy = down.position.y / h
                            val slop = 0.04f
                            val hit = curRendered?.blocks?.lastOrNull {
                                fx >= it.l - slop && fx <= it.r + slop && fy >= it.t - slop && fy <= it.b + slop
                            }
                            val aIdx = curACue?.index ?: -1
                            val lIdx = curLCue?.index ?: -1
                            // 0 = baris Arab, 1 = baris Inggris, 2 = kotak latar, -1 = tidak ada (biarkan scroll)
                            val target = when {
                                hit != null && hit.track == 0 && aIdx >= 0 -> 0
                                hit != null && hit.track == 1 && lIdx >= 0 -> 1
                                curStyle.boxEnabled -> 2
                                else -> -1
                            }
                            if (target < 0) return@awaitEachGesture
                            drag(down.id) { change ->
                                val d = change.positionChange()
                                change.consume()
                                val px = d.x / w * 100f
                                val py = d.y / h * 100f
                                when (target) {
                                    0 -> vm.moveLine(true, aIdx, px, py)
                                    1 -> vm.moveLine(false, lIdx, px, py)
                                    else -> vm.updateStyle { st ->
                                        st.copy(
                                            boxOffsetX = (st.boxOffsetX + px).coerceIn(-50f, 50f),
                                            boxOffsetY = (st.boxOffsetY + py).coerceIn(-50f, 50f)
                                        )
                                    }
                                }
                            }
                        }
                    }
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setPlayer(exo)
                        }
                    }
                )
                if (image != null) {
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.FillBounds
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = {
                if (exo.isPlaying) {
                    exo.pause()
                } else {
                    if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0)
                    exo.play()
                }
            }) {
                Text(if (playing) "Jeda" else "Putar")
            }
            Text(
                formatTime(positionMs) + " / " + formatTime(info.durationMs),
                color = Color.Gray
            )
        }
        Slider(
            value = positionMs.toFloat().coerceIn(0f, duration),
            onValueChange = {
                positionMs = it.toLong()
                exo.seekTo(it.toLong())
            },
            valueRange = 0f..duration
        )

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Geser baris/kotak di preview", color = Color.Gray)
            Spacer(Modifier.weight(1f))
            Switch(checked = dragMode, onCheckedChange = { dragMode = it })
        }
        if (dragMode) {
            Text(
                "Jeda video, lalu geser teks subtitle dengan jari. Hanya baris yang sedang tampil yang bergeser. Matikan saklar ini jika ingin scroll halaman dari area video.",
                color = Color.Gray
            )
        }
        if (hasOffsets) {
            OutlinedButton(onClick = { vm.resetLineOffsets() }) { Text("Reset posisi semua baris") }
        }
        if (noCues) {
            Text("Contoh teks ditampilkan. Muat file SRT untuk subtitle asli.", color = Color.Gray)
        }
    }
}

private fun formatTime(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}
