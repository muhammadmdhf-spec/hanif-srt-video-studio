package com.subtitleeditor.app.video

import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import com.subtitleeditor.app.render.SubtitleRenderer
import com.subtitleeditor.app.srt.Cue
import com.subtitleeditor.app.srt.SrtParser
import com.subtitleeditor.app.style.LineOffset
import com.subtitleeditor.app.style.SubtitleStyle

/**
 * Overlay untuk Media3 Transformer: untuk setiap frame video mengembalikan
 * bitmap transparan (seukuran frame) berisi subtitle yang sedang aktif.
 * Bitmap hanya digambar ulang saat teks atau posisi berubah.
 */
@OptIn(UnstableApi::class)
class SubtitleOverlay(
    private val width: Int,
    private val height: Int,
    private val style: SubtitleStyle,
    private val arabicTf: Typeface,
    private val latinTf: Typeface,
    private val arabicCues: List<Cue>,
    private val latinCues: List<Cue>,
    private val arabicOffsets: Map<Int, LineOffset>,
    private val latinOffsets: Map<Int, LineOffset>
) : BitmapOverlay() {

    private val empty: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private var lastKey: String? = null
    private var lastBitmap: Bitmap = empty

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val tMs = presentationTimeUs / 1000L
        val a = SrtParser.activeText(arabicCues, tMs)
        val l = SrtParser.activeText(latinCues, tMs)
        if (a == null && l == null) return empty
        val ac = SrtParser.activeCue(arabicCues, tMs)
        val lc = SrtParser.activeCue(latinCues, tMs)
        val ao = if (ac != null) arabicOffsets[ac.index] ?: LineOffset() else LineOffset()
        val lo = if (lc != null) latinOffsets[lc.index] ?: LineOffset() else LineOffset()
        val key = (a ?: "") + "\u0000" + (l ?: "") + "\u0000" + ao + "\u0000" + lo
        if (key == lastKey) return lastBitmap
        lastBitmap = SubtitleRenderer.render(width, height, style, arabicTf, latinTf, a, l, ao, lo)
        lastKey = key
        return lastBitmap
    }
}
