package com.subtitleeditor.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.subtitleeditor.app.MainViewModel
import com.subtitleeditor.app.style.BoxShape
import com.subtitleeditor.app.style.BoxTheme
import com.subtitleeditor.app.style.DisplayMode
import com.subtitleeditor.app.style.TextAlignMode
import com.subtitleeditor.app.style.Themes

private val WEIGHTS = listOf("Regular" to 0, "Medium" to 1, "Bold" to 2)

@Composable
fun StylePanel(vm: MainViewModel) {
    val s = vm.style

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Tampilkan", style = MaterialTheme.typography.bodyMedium)
        ChipRow(
            listOf(
                "Arab saja" to DisplayMode.ARABIC,
                "Inggris/Indonesia saja" to DisplayMode.LATIN,
                "Keduanya" to DisplayMode.BOTH
            ),
            s.display
        ) { v -> vm.updateStyle { it.copy(display = v) } }

        HorizontalDivider()
        Text("Tema warna subtitle", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Themes.colorThemes.forEach { t ->
                FilterChip(
                    selected = Themes.isColorThemeActive(s, t),
                    onClick = { vm.updateStyle { Themes.applyColorTheme(it, t) } },
                    label = { Text(t.name, color = Color(t.arabic)) }
                )
            }
        }

        HorizontalDivider()
        Text("Teks Arab", style = MaterialTheme.typography.titleSmall)
        FontDropdown("Font Arab", vm.fonts.arabicFonts, s.arabicFont) { k ->
            vm.updateStyle { it.copy(arabicFont = k) }
        }
        ChipRow(WEIGHTS, s.arabicWeight) { w -> vm.updateStyle { it.copy(arabicWeight = w) } }
        LabeledSlider("Ukuran", String.format("%.1f", s.arabicSizePct), s.arabicSizePct, 2f..10f) { v ->
            vm.updateStyle { it.copy(arabicSizePct = v) }
        }
        ColorRow("Warna teks Arab", s.arabicColor) { c -> vm.updateStyle { it.copy(arabicColor = c) } }

        HorizontalDivider()
        Text("Teks Inggris / Indonesia", style = MaterialTheme.typography.titleSmall)
        FontDropdown("Font alfabet", vm.fonts.latinFonts, s.latinFont) { k ->
            vm.updateStyle { it.copy(latinFont = k) }
        }
        ChipRow(WEIGHTS, s.latinWeight) { w -> vm.updateStyle { it.copy(latinWeight = w) } }
        LabeledSlider("Ukuran", String.format("%.1f", s.latinSizePct), s.latinSizePct, 2f..10f) { v ->
            vm.updateStyle { it.copy(latinSizePct = v) }
        }
        ColorRow("Warna teks Inggris", s.latinColor) { c -> vm.updateStyle { it.copy(latinColor = c) } }

        HorizontalDivider()
        Text("Outline, posisi, rata teks", style = MaterialTheme.typography.titleSmall)
        ColorRow("Warna outline", s.outlineColor) { c -> vm.updateStyle { it.copy(outlineColor = c) } }
        LabeledSlider("Ketebalan outline", String.format("%.1f", s.outlineWidth), s.outlineWidth, 0f..10f) { v ->
            vm.updateStyle { it.copy(outlineWidth = v) }
        }
        LabeledSlider("Posisi vertikal (0 = atas, 100 = bawah)", s.positionPct.toInt().toString(), s.positionPct, 0f..100f) { v ->
            vm.updateStyle { it.copy(positionPct = v) }
        }
        ChipRow(
            listOf("Kiri" to TextAlignMode.LEFT, "Tengah" to TextAlignMode.CENTER, "Kanan" to TextAlignMode.RIGHT),
            s.align
        ) { a -> vm.updateStyle { it.copy(align = a) } }

        HorizontalDivider()
        Text("Efek kata dinamis", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = s.highlightWord,
            onValueChange = { v -> vm.updateStyle { it.copy(highlightWord = v) } },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Kata yang disorot (pisahkan dengan koma)") },
            placeholder = { Text("contoh: ayam, sapi") }
        )
        LabeledSlider(
            "Ukuran kata sorotan",
            String.format("%.1fx", s.highlightScale),
            s.highlightScale,
            1f..3f
        ) { v -> vm.updateStyle { it.copy(highlightScale = v) } }
        ColorRow("Warna kata sorotan", s.highlightColor) { c -> vm.updateStyle { it.copy(highlightColor = c) } }
        Text("Kosongkan kolom kata untuk mematikan efek. Berlaku di teks Arab dan Inggris.", color = Color.Gray)

        HorizontalDivider()
        BoxPanel(vm)

        OutlinedButton(onClick = { vm.resetStyle() }, modifier = Modifier.fillMaxWidth()) {
            Text("Reset ke Default")
        }
    }
}

@Composable
private fun BoxPanel(vm: MainViewModel) {
    val s = vm.style

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Kotak latar (opsional)", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.weight(1f))
        Switch(
            checked = s.boxEnabled,
            onCheckedChange = { on -> vm.updateStyle { it.copy(boxEnabled = on) } }
        )
    }
    if (!s.boxEnabled) {
        Text("Nyalakan untuk memasang kotak di belakang subtitle.", color = Color.Gray)
        return
    }

    Text("Tema kotak", style = MaterialTheme.typography.bodyMedium)
    ChipRow(
        BoxTheme.entries.map { it.label to it },
        s.boxTheme
    ) { t -> vm.updateStyle { Themes.applyBoxTheme(it, t) } }

    Text("Bentuk", style = MaterialTheme.typography.bodyMedium)
    ChipRow(
        BoxShape.entries.map { it.label to it },
        s.boxShape
    ) { sh -> vm.updateStyle { it.copy(boxShape = sh) } }

    Text("Warna isi", style = MaterialTheme.typography.bodyMedium)
    ChipRow(
        listOf("Solid" to false, "Gradient" to true),
        s.boxGradient
    ) { g -> vm.updateStyle { it.copy(boxGradient = g) } }
    ColorRow(if (s.boxGradient) "Warna awal" else "Warna kotak", s.boxColor1) { c ->
        vm.updateStyle { it.copy(boxColor1 = c) }
    }
    if (s.boxGradient) {
        ColorRow("Warna akhir", s.boxColor2) { c -> vm.updateStyle { it.copy(boxColor2 = c) } }
    }
    LabeledSlider(
        "Transparansi (0 = bening, 100 = pekat)",
        (s.boxOpacity * 100f).toInt().toString(),
        s.boxOpacity,
        0f..1f
    ) { v -> vm.updateStyle { it.copy(boxOpacity = v) } }

    Text("Ukuran kotak", style = MaterialTheme.typography.bodyMedium)
    LabeledSlider("Padding", String.format("%.1f", s.boxPadding), s.boxPadding, 0f..10f) { v ->
        vm.updateStyle { it.copy(boxPadding = v) }
    }
    LabeledSlider("Lebar", (s.boxScaleW * 100f).toInt().toString() + "%", s.boxScaleW, 0.5f..2f) { v ->
        vm.updateStyle { it.copy(boxScaleW = v) }
    }
    LabeledSlider("Tinggi", (s.boxScaleH * 100f).toInt().toString() + "%", s.boxScaleH, 0.5f..2f) { v ->
        vm.updateStyle { it.copy(boxScaleH = v) }
    }

    Text("Posisi kotak (atau geser langsung di preview video)", style = MaterialTheme.typography.bodyMedium)
    LabeledSlider("Geser horizontal", s.boxOffsetX.toInt().toString(), s.boxOffsetX, -50f..50f) { v ->
        vm.updateStyle { it.copy(boxOffsetX = v) }
    }
    LabeledSlider("Geser vertikal", s.boxOffsetY.toInt().toString(), s.boxOffsetY, -50f..50f) { v ->
        vm.updateStyle { it.copy(boxOffsetY = v) }
    }
    OutlinedButton(
        onClick = { vm.updateStyle { it.copy(boxOffsetX = 0f, boxOffsetY = 0f) } },
        modifier = Modifier.fillMaxWidth()
    ) { Text("Kembalikan kotak ke tengah teks") }

    Text("Garis tepi dan bayangan", style = MaterialTheme.typography.bodyMedium)
    LabeledSlider("Tebal garis tepi", String.format("%.1f", s.boxStrokeWidth), s.boxStrokeWidth, 0f..10f) { v ->
        vm.updateStyle { it.copy(boxStrokeWidth = v) }
    }
    ColorRow("Warna garis tepi", s.boxStrokeColor) { c -> vm.updateStyle { it.copy(boxStrokeColor = c) } }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Bayangan")
        Spacer(Modifier.weight(1f))
        Switch(checked = s.boxShadow, onCheckedChange = { on -> vm.updateStyle { it.copy(boxShadow = on) } })
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Tepi lembut (efek blur pada kotak)")
        Spacer(Modifier.weight(1f))
        Switch(checked = s.boxSoft, onCheckedChange = { on -> vm.updateStyle { it.copy(boxSoft = on) } })
    }
}
