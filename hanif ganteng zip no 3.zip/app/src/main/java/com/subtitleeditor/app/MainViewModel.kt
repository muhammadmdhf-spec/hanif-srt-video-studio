package com.subtitleeditor.app

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.subtitleeditor.app.fonts.FontRepository
import com.subtitleeditor.app.srt.Cue
import com.subtitleeditor.app.srt.SrtParser
import com.subtitleeditor.app.style.DisplayMode
import com.subtitleeditor.app.style.LineOffset
import com.subtitleeditor.app.style.StyleStore
import com.subtitleeditor.app.style.SubtitleStyle
import com.subtitleeditor.app.video.SubtitleOverlay
import com.subtitleeditor.app.video.VideoExporter
import com.subtitleeditor.app.video.VideoInfo
import com.subtitleeditor.app.video.VideoProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val appContext: Context = app.applicationContext

    val fonts = FontRepository(appContext)
    private val store = StyleStore(appContext)
    val exporter = VideoExporter(appContext)

    var style by mutableStateOf(fonts.sanitize(store.load()))
        private set

    var videoUri by mutableStateOf<Uri?>(null)
        private set
    var videoName by mutableStateOf<String?>(null)
        private set
    var videoInfo by mutableStateOf<VideoInfo?>(null)
        private set

    var arabicCues by mutableStateOf<List<Cue>>(emptyList())
        private set
    var latinCues by mutableStateOf<List<Cue>>(emptyList())
        private set
    var arabicName by mutableStateOf<String?>(null)
        private set
    var latinName by mutableStateOf<String?>(null)
        private set

    // Pergeseran manual per baris SRT (kunci = nomor baris di file SRT)
    var arabicOffsets by mutableStateOf<Map<Int, LineOffset>>(emptyMap())
        private set
    var latinOffsets by mutableStateOf<Map<Int, LineOffset>>(emptyMap())
        private set

    var message by mutableStateOf<String?>(null)
    var pendingSave by mutableStateOf(false)
    var exportedFile by mutableStateOf<File?>(null)
        private set

    // ---------- Gaya ----------

    fun updateStyle(transform: (SubtitleStyle) -> SubtitleStyle) {
        style = transform(style)
        store.save(style)
    }

    fun resetStyle() {
        store.clear()
        style = fonts.sanitize(SubtitleStyle())
        message = "Pengaturan dikembalikan ke default"
    }

    // ---------- Video ----------

    fun loadVideo(uri: Uri) {
        viewModelScope.launch {
            val info = withContext(Dispatchers.IO) { VideoProbe.probe(appContext, uri) }
            if (info == null) {
                message = "Video tidak bisa dibaca. Coba video lain."
                return@launch
            }
            videoUri = uri
            videoInfo = info
            videoName = queryName(uri) ?: "video"
            exportedFile = null
            exporter.reset()
            if (info.durationMs > 60_000L) {
                message = "Video lebih dari 1 menit, proses ekspor bisa lama."
            }
        }
    }

    // ---------- SRT ----------

    fun loadSrt(uri: Uri, arabic: Boolean) {
        viewModelScope.launch {
            val raw = withContext(Dispatchers.IO) {
                try {
                    appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } catch (e: Exception) {
                    null
                }
            }
            if (raw == null) {
                message = "File SRT tidak bisa dibaca"
                return@launch
            }
            applyCues(SrtParser.parse(SrtParser.decode(raw)), queryName(uri) ?: "subtitle.srt", arabic)
        }
    }

    fun setSrtText(text: String, arabic: Boolean) {
        applyCues(SrtParser.parse(text), "(ditempel)", arabic)
    }

    fun clearSrt(arabic: Boolean) {
        if (arabic) {
            arabicCues = emptyList()
            arabicName = null
            arabicOffsets = emptyMap()
        } else {
            latinCues = emptyList()
            latinName = null
            latinOffsets = emptyMap()
        }
    }

    /** Menggeser satu baris SRT (dalam persen lebar/tinggi frame). */
    fun moveLine(arabic: Boolean, cueIndex: Int, ddx: Float, ddy: Float) {
        val map = if (arabic) arabicOffsets else latinOffsets
        val cur = map[cueIndex] ?: LineOffset()
        val next = LineOffset(
            (cur.dx + ddx).coerceIn(-100f, 100f),
            (cur.dy + ddy).coerceIn(-100f, 100f)
        )
        if (arabic) {
            arabicOffsets = arabicOffsets + (cueIndex to next)
        } else {
            latinOffsets = latinOffsets + (cueIndex to next)
        }
    }

    fun resetLineOffsets() {
        arabicOffsets = emptyMap()
        latinOffsets = emptyMap()
    }

    private fun applyCues(cues: List<Cue>, name: String, arabic: Boolean) {
        if (cues.isEmpty()) {
            message = "Tidak ada subtitle valid yang ditemukan di SRT"
            return
        }
        if (arabic) {
            arabicCues = cues
            arabicName = name
            arabicOffsets = emptyMap()
        } else {
            latinCues = cues
            latinName = name
            latinOffsets = emptyMap()
        }
        message = "${cues.size} baris subtitle dimuat"
    }

    // ---------- Ekspor ----------

    fun startExport() {
        val uri = videoUri ?: run {
            message = "Pilih video dulu"
            return
        }
        val info = videoInfo ?: return
        val st = style
        val showA = st.display != DisplayMode.LATIN
        val showL = st.display != DisplayMode.ARABIC
        val a = if (showA) arabicCues else emptyList()
        val l = if (showL) latinCues else emptyList()
        if (a.isEmpty() && l.isEmpty()) {
            message = "Muat file SRT yang sesuai pilihan tampilan dulu"
            return
        }
        appContext.cacheDir.listFiles()?.forEach {
            if (it.name.startsWith("export_")) it.delete()
        }
        val overlay = SubtitleOverlay(
            info.width,
            info.height,
            st,
            fonts.typeface(st.arabicFont, st.arabicWeight),
            fonts.typeface(st.latinFont, st.latinWeight),
            a,
            l,
            if (showA) arabicOffsets else emptyMap(),
            if (showL) latinOffsets else emptyMap()
        )
        exportedFile = null
        val out = File(appContext.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        exporter.start(viewModelScope, uri, overlay, out)
    }

    /** Dipanggil UI saat status ekspor menjadi selesai. */
    fun onExportDone(file: File) {
        if (exportedFile != file) {
            exportedFile = file
            pendingSave = true
        }
    }

    fun cancelExport() {
        exporter.cancel()
    }

    fun saveExport(dest: Uri) {
        val f = exportedFile ?: return
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val out = appContext.contentResolver.openOutputStream(dest)
                    if (out == null) {
                        false
                    } else {
                        out.use { o -> f.inputStream().use { it.copyTo(o) } }
                        true
                    }
                } catch (e: Exception) {
                    false
                }
            }
            message = if (ok) "Video tersimpan" else "Gagal menyimpan video"
        }
    }

    fun exportSrt(arabic: Boolean, dest: Uri) {
        val cues = if (arabic) arabicCues else latinCues
        if (cues.isEmpty()) return
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val out = appContext.contentResolver.openOutputStream(dest)
                    if (out == null) {
                        false
                    } else {
                        out.use { it.write(SrtParser.write(cues).toByteArray(Charsets.UTF_8)) }
                        true
                    }
                } catch (e: Exception) {
                    false
                }
            }
            message = if (ok) "SRT tersimpan" else "Gagal menyimpan SRT"
        }
    }

    fun suggestedName(suffix: String, ext: String): String {
        val base = (videoName ?: "video").substringBeforeLast('.').ifBlank { "video" }
        return "${base}_$suffix.$ext"
    }

    private fun queryName(uri: Uri): String? {
        return try {
            appContext.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i) else null
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun onCleared() {
        exporter.cancel()
        super.onCleared()
    }
}
