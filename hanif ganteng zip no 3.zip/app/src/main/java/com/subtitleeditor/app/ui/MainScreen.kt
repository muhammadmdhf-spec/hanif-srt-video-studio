package com.subtitleeditor.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.subtitleeditor.app.MainViewModel
import com.subtitleeditor.app.video.VideoExporter

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val exportState by vm.exporter.state.collectAsState()

    // true = Arab, false = Inggris, null = dialog tutup
    var pasteTarget by remember { mutableStateOf<Boolean?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.loadVideo(uri)
    }
    val arabicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.loadSrt(uri, true)
    }
    val latinPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.loadSrt(uri, false)
    }
    val mp4Saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null) vm.saveExport(uri)
    }
    val arabicSrtSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) vm.exportSrt(true, uri)
    }
    val latinSrtSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) vm.exportSrt(false, uri)
    }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            Toast.makeText(context, m, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    LaunchedEffect(exportState) {
        val s = exportState
        if (s is VideoExporter.State.Done) vm.onExportDone(s.file)
    }

    LaunchedEffect(vm.pendingSave) {
        if (vm.pendingSave) {
            vm.pendingSave = false
            mp4Saver.launch(vm.suggestedName("subtitle", "mp4"))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Editor Subtitle", style = MaterialTheme.typography.headlineSmall)

        SectionCard("1. Video") {
            PreviewPlayer(vm)
            Button(onClick = { videoPicker.launch("video/*") }) {
                Text(if (vm.videoUri == null) "Pilih video dari galeri" else "Ganti video")
            }
            vm.videoName?.let {
                Text(it, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        SectionCard("2. Subtitle (SRT)") {
            SrtRow(
                title = "Arab",
                fileName = vm.arabicName,
                count = vm.arabicCues.size,
                onPick = { arabicPicker.launch(arrayOf("*/*")) },
                onPaste = { pasteTarget = true },
                onClear = { vm.clearSrt(true) }
            )
            SrtRow(
                title = "Inggris / Indonesia",
                fileName = vm.latinName,
                count = vm.latinCues.size,
                onPick = { latinPicker.launch(arrayOf("*/*")) },
                onPaste = { pasteTarget = false },
                onClear = { vm.clearSrt(false) }
            )
        }

        SectionCard("3. Gaya subtitle") {
            StylePanel(vm)
        }

        SectionCard("4. Ekspor") {
            when (val s = exportState) {
                is VideoExporter.State.Running -> {
                    LinearProgressIndicator(
                        progress = { s.percent / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Merender video... ${s.percent}%")
                    Text("Jangan tutup aplikasi selama proses berjalan.", color = Color.Gray)
                    OutlinedButton(onClick = { vm.cancelExport() }) { Text("Batalkan") }
                }

                else -> {
                    Button(
                        onClick = { vm.startExport() },
                        enabled = vm.videoUri != null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Download MP4")
                    }
                    if (s is VideoExporter.State.Failed) {
                        Text(s.message, color = MaterialTheme.colorScheme.error)
                    }
                    if (s is VideoExporter.State.Done) {
                        Text("Render selesai.", color = MaterialTheme.colorScheme.primary)
                        OutlinedButton(
                            onClick = { mp4Saver.launch(vm.suggestedName("subtitle", "mp4")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Simpan MP4 lagi")
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { arabicSrtSaver.launch(vm.suggestedName("ar", "srt")) },
                    enabled = vm.arabicCues.isNotEmpty()
                ) { Text("Download SRT Arab") }
                OutlinedButton(
                    onClick = { latinSrtSaver.launch(vm.suggestedName("en", "srt")) },
                    enabled = vm.latinCues.isNotEmpty()
                ) { Text("Download SRT Inggris") }
            }
        }

        Spacer(Modifier.padding(8.dp))
    }

    val target = pasteTarget
    if (target != null) {
        PasteDialog(
            title = if (target) "Tempel SRT Arab" else "Tempel SRT Inggris/Indonesia",
            onDismiss = { pasteTarget = null },
            onApply = { text ->
                vm.setSrtText(text, target)
                pasteTarget = null
            }
        )
    }
}

@Composable
private fun SrtRow(
    title: String,
    fileName: String?,
    count: Int,
    onPick: () -> Unit,
    onPaste: () -> Unit,
    onClear: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(
            if (fileName == null) "Belum dimuat" else "$fileName ($count baris)",
            color = Color.Gray,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onPick) { Text("Pilih file") }
            OutlinedButton(onClick = onPaste) { Text("Tempel") }
            if (fileName != null) {
                TextButton(onClick = onClear) { Text("Hapus") }
            }
        }
    }
}

@Composable
private fun PasteDialog(title: String, onDismiss: () -> Unit, onApply: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 6,
                maxLines = 12,
                placeholder = { Text("1\n00:00:01,000 --> 00:00:03,000\nTeks subtitle") }
            )
        },
        confirmButton = { TextButton(onClick = { onApply(text) }) { Text("Terapkan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
