package com.subtitleeditor.app.style

enum class BoxShape(val label: String) {
    RECT("Kotak"),
    ROUNDED("Rounded"),
    OVAL("Oval"),
    PILL("Pill"),
    BANNER("Banner"),
    BUBBLE("Bubble"),
    RIBBON("Ribbon"),
    STAMP("Stamp"),
    TAPE("Tape")
}

enum class BoxTheme(val label: String) {
    SOLID_BLACK("Solid Black"),
    SOFT_BLACK("Soft Black"),
    GLASS("Glass"),
    BLUR("Blur"),
    GRADIENT_BLUE("Gradient Blue"),
    GRADIENT_SUNSET("Gradient Sunset"),
    GRADIENT_GREEN("Gradient Green"),
    OUTLINE_ONLY("Outline Only"),
    SHADOW_ONLY("Shadow Only"),
    PILL_SHAPE("Pill Shape"),
    BUBBLE("Bubble"),
    RIBBON("Ribbon"),
    BANNER("Banner"),
    STAMP("Stamp"),
    TAPE("Tape")
}

data class ColorTheme(
    val name: String,
    val arabic: Int,
    val latin: Int,
    val outline: Int,
    val outlineWidth: Float
)

object Themes {

    private fun c(v: Long): Int = v.toInt()

    val colorThemes: List<ColorTheme> = listOf(
        ColorTheme("Classic White", c(0xFFFFFFFF), c(0xFFFFFFFF), c(0xFF000000), 3f),
        ColorTheme("Golden Dawn", c(0xFFFFD54F), c(0xFFFFF3C4), c(0xFF4E2A00), 3f),
        ColorTheme("Royal Blue", c(0xFF82B1FF), c(0xFFE3F2FD), c(0xFF0D1B4C), 3f),
        ColorTheme("Emerald", c(0xFF69F0AE), c(0xFFE8F5E9), c(0xFF00432A), 3f),
        ColorTheme("Sunset", c(0xFFFFAB76), c(0xFFFFE0B2), c(0xFF5A1A00), 3f),
        ColorTheme("Midnight", c(0xFFC5CAE9), c(0xFFE8EAF6), c(0xFF0A0A23), 3.5f),
        ColorTheme("Rose Gold", c(0xFFFFD1C1), c(0xFFFCE4EC), c(0xFF5C2E2E), 3f),
        ColorTheme("Neon", c(0xFF39FF14), c(0xFF00E5FF), c(0xFF000000), 3.5f),
        ColorTheme("Minimalist", c(0xFFF5F5F5), c(0xFFF5F5F5), c(0xFF333333), 1f),
        ColorTheme("Vintage", c(0xFFF3E5AB), c(0xFFEADBB0), c(0xFF5D4037), 3f),
        ColorTheme("Ocean", c(0xFF80DEEA), c(0xFFE0F7FA), c(0xFF004D60), 3f),
        ColorTheme("Lava", c(0xFFFF6E40), c(0xFFFFCCBC), c(0xFF3B0A00), 3.5f),
        ColorTheme("Forest", c(0xFFA5D6A7), c(0xFFDCEDC8), c(0xFF1B3A1E), 3f),
        ColorTheme("Lavender", c(0xFFD1C4E9), c(0xFFEDE7F6), c(0xFF3B2A66), 3f),
        ColorTheme("Coral", c(0xFFFF8A80), c(0xFFFFCDD2), c(0xFF5A1A1A), 3f)
    )

    fun applyColorTheme(s: SubtitleStyle, t: ColorTheme): SubtitleStyle = s.copy(
        arabicColor = t.arabic,
        latinColor = t.latin,
        outlineColor = t.outline,
        outlineWidth = t.outlineWidth
    )

    fun isColorThemeActive(s: SubtitleStyle, t: ColorTheme): Boolean =
        s.arabicColor == t.arabic && s.latinColor == t.latin && s.outlineColor == t.outline

    /** Menerapkan tema kotak latar. Posisi, ukuran, dan padding kotak tidak diubah. */
    fun applyBoxTheme(s: SubtitleStyle, t: BoxTheme): SubtitleStyle {
        val base = s.copy(
            boxEnabled = true,
            boxTheme = t,
            boxGradient = false,
            boxColor1 = c(0xFF000000),
            boxColor2 = c(0xFF000000),
            boxOpacity = 1f,
            boxStrokeWidth = 0f,
            boxStrokeColor = c(0xFFFFFFFF),
            boxShadow = false,
            boxSoft = false
        )
        return when (t) {
            BoxTheme.SOLID_BLACK -> base.copy(boxShape = BoxShape.RECT)
            BoxTheme.SOFT_BLACK -> base.copy(boxShape = BoxShape.ROUNDED, boxOpacity = 0.6f)
            BoxTheme.GLASS -> base.copy(
                boxShape = BoxShape.ROUNDED, boxGradient = true,
                boxColor1 = c(0xFFFFFFFF), boxColor2 = c(0xFF9FC5E8), boxOpacity = 0.28f,
                boxStrokeWidth = 1.5f, boxStrokeColor = c(0xFFFFFFFF), boxShadow = true
            )
            BoxTheme.BLUR -> base.copy(
                boxShape = BoxShape.ROUNDED, boxColor1 = c(0xFF202020),
                boxOpacity = 0.5f, boxSoft = true
            )
            BoxTheme.GRADIENT_BLUE -> base.copy(
                boxShape = BoxShape.ROUNDED, boxGradient = true,
                boxColor1 = c(0xFF1E3C72), boxColor2 = c(0xFF2A9DF4), boxOpacity = 0.92f
            )
            BoxTheme.GRADIENT_SUNSET -> base.copy(
                boxShape = BoxShape.ROUNDED, boxGradient = true,
                boxColor1 = c(0xFFFF5E62), boxColor2 = c(0xFFFF9966), boxOpacity = 0.92f
            )
            BoxTheme.GRADIENT_GREEN -> base.copy(
                boxShape = BoxShape.ROUNDED, boxGradient = true,
                boxColor1 = c(0xFF11998E), boxColor2 = c(0xFF38EF7D), boxOpacity = 0.92f
            )
            BoxTheme.OUTLINE_ONLY -> base.copy(
                boxShape = BoxShape.ROUNDED, boxOpacity = 0f,
                boxStrokeWidth = 3f, boxStrokeColor = c(0xFFFFFFFF)
            )
            BoxTheme.SHADOW_ONLY -> base.copy(
                boxShape = BoxShape.ROUNDED, boxOpacity = 0f, boxShadow = true
            )
            BoxTheme.PILL_SHAPE -> base.copy(boxShape = BoxShape.PILL, boxOpacity = 0.75f)
            BoxTheme.BUBBLE -> base.copy(
                boxShape = BoxShape.BUBBLE, boxColor1 = c(0xFF1F6FEB), boxOpacity = 0.95f
            )
            BoxTheme.RIBBON -> base.copy(
                boxShape = BoxShape.RIBBON, boxColor1 = c(0xFFC62828), boxOpacity = 0.95f
            )
            BoxTheme.BANNER -> base.copy(boxShape = BoxShape.BANNER, boxOpacity = 0.7f)
            BoxTheme.STAMP -> base.copy(
                boxShape = BoxShape.STAMP, boxColor1 = c(0xFFD32F2F), boxOpacity = 0.2f,
                boxStrokeWidth = 3f, boxStrokeColor = c(0xFFD32F2F)
            )
            BoxTheme.TAPE -> base.copy(
                boxShape = BoxShape.TAPE, boxColor1 = c(0xFFF9A825), boxOpacity = 0.88f
            )
        }
    }
}
