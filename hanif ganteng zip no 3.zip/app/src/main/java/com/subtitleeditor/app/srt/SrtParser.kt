package com.subtitleeditor.app.srt

import java.nio.charset.Charset
import java.util.Locale

data class Cue(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String
)

object SrtParser {

    private val TIME_LINE = Regex(
        """(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"""
    )
    private val HTML_TAG = Regex("<[^>]*>")
    private val ASS_TAG = Regex("""\{\\[^}]*\}""")

    /** Membaca byte file SRT menjadi teks (UTF-8, UTF-16, atau Windows-1256 untuk Arab lama). */
    fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, Charsets.UTF_16BE)
        }
        val utf8 = String(bytes, Charsets.UTF_8)
        if (!utf8.contains('\uFFFD')) return utf8
        return try {
            String(bytes, Charset.forName("windows-1256"))
        } catch (e: Exception) {
            utf8
        }
    }

    fun parse(raw: String): List<Cue> {
        val text = raw.replace("\uFEFF", "").replace("\r\n", "\n").replace('\r', '\n')
        val lines = text.split("\n")
        val result = ArrayList<Cue>()
        var i = 0
        while (i < lines.size) {
            val m = TIME_LINE.find(lines[i])
            if (m == null) {
                i++
                continue
            }
            val g = m.groupValues
            val start = toMs(g[1], g[2], g[3], g[4])
            val end = toMs(g[5], g[6], g[7], g[8])
            i++
            val body = ArrayList<String>()
            while (i < lines.size && lines[i].isNotBlank()) {
                val line = lines[i]
                if (TIME_LINE.containsMatchIn(line)) break
                val isIndexLine = line.trim().all { it.isDigit() } &&
                    i + 1 < lines.size && TIME_LINE.containsMatchIn(lines[i + 1])
                if (isIndexLine) break
                body.add(clean(line))
                i++
            }
            val content = body.joinToString("\n").trim()
            if (content.isNotEmpty() && end > start) {
                result.add(Cue(0, start, end, content))
            }
        }
        return result
            .sortedBy { it.startMs }
            .mapIndexed { idx, c -> c.copy(index = idx + 1) }
    }

    private fun clean(line: String): String =
        line.replace(HTML_TAG, "").replace(ASS_TAG, "").trim()

    private fun toMs(h: String, m: String, s: String, f: String): Long {
        val frac = f.padEnd(3, '0').take(3)
        return h.toLong() * 3_600_000L + m.toLong() * 60_000L + s.toLong() * 1000L + frac.toLong()
    }

    /** Teks subtitle yang aktif pada waktu tertentu (null jika tidak ada). */
    fun activeText(cues: List<Cue>, tMs: Long): String? {
        var result: String? = null
        for (c in cues) {
            if (c.startMs > tMs) break
            if (tMs < c.endMs) {
                result = if (result == null) c.text else result + "\n" + c.text
            }
        }
        return result
    }

    /** Baris pertama yang aktif pada waktu tertentu (null jika tidak ada). */
    fun activeCue(cues: List<Cue>, tMs: Long): Cue? {
        for (c in cues) {
            if (c.startMs > tMs) break
            if (tMs < c.endMs) return c
        }
        return null
    }

    fun write(cues: List<Cue>): String {
        val sb = StringBuilder()
        cues.forEachIndexed { i, c ->
            sb.append(i + 1).append('\n')
            sb.append(format(c.startMs)).append(" --> ").append(format(c.endMs)).append('\n')
            sb.append(c.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun format(ms: Long): String {
        val h = ms / 3_600_000L
        val m = (ms / 60_000L) % 60
        val s = (ms / 1000L) % 60
        val f = ms % 1000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, f)
    }
}
