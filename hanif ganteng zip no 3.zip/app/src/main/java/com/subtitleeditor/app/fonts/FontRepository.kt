package com.subtitleeditor.app.fonts

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import com.subtitleeditor.app.style.SubtitleStyle
import java.util.concurrent.ConcurrentHashMap

data class FontOption(val key: String, val label: String)

/**
 * Membaca semua font di assets/fonts/ secara otomatis.
 * Font yang tidak berhasil diunduh saat build tidak akan muncul di daftar,
 * dan aplikasi tetap berjalan (memakai font sistem sebagai cadangan).
 */
class FontRepository(private val context: Context) {

    companion object {
        const val SYSTEM = "System"

        private val ARABIC_FAMILIES = setOf(
            "Amiri", "ScheherazadeNew", "Lateef", "NotoNaskhArabic", "Cairo", "Tajawal",
            "Almarai", "ReemKufi", "ArefRuqaa", "ElMessiri", "Changa", "Harmattan",
            "Mirza", "Gulzar"
        )
    }

    private val files: List<String> = try {
        context.assets.list("fonts")
            ?.filter { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }
            ?.sorted()
            ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private val cache = ConcurrentHashMap<String, Typeface>()

    private val families: List<String> = files.map { familyOf(it) }.distinct()

    val arabicFonts: List<FontOption> =
        families.filter { it in ARABIC_FAMILIES }.map { FontOption(it, humanize(it)) } +
            FontOption(SYSTEM, "Sistem (bawaan)")

    val latinFonts: List<FontOption> =
        families.filter { it !in ARABIC_FAMILIES }.map { FontOption(it, humanize(it)) } +
            FontOption(SYSTEM, "Sistem (bawaan)")

    fun sanitize(s: SubtitleStyle): SubtitleStyle = s.copy(
        arabicFont = pick(s.arabicFont, arabicFonts, "Amiri"),
        latinFont = pick(s.latinFont, latinFonts, "Arimo")
    )

    private fun pick(name: String, options: List<FontOption>, preferred: String): String {
        if (options.any { it.key == name }) return name
        return options.firstOrNull { it.key == preferred }?.key ?: options.first().key
    }

    fun typeface(family: String, weightIdx: Int): Typeface =
        cache.getOrPut("$family/$weightIdx") { build(family, weightIdx) }

    private fun familyOf(file: String): String =
        file.substringBeforeLast('.').substringBefore('[').substringBefore('-')

    private fun humanize(name: String): String =
        name.replace(Regex("(?<=[a-z])(?=[A-Z0-9])"), " ")

    private fun build(family: String, weightIdx: Int): Typeface {
        val wght = when (weightIdx) {
            0 -> 400
            1 -> 500
            else -> 700
        }
        if (family == SYSTEM) return systemTypeface(wght)
        val mine = files.filter { familyOf(it) == family }
        if (mine.isEmpty()) return systemTypeface(wght)

        val suffix = when (weightIdx) {
            0 -> "Regular"
            1 -> "Medium"
            else -> "Bold"
        }
        val exact = mine.firstOrNull {
            it.substringBeforeLast('.').endsWith("-$suffix", ignoreCase = true)
        }
        if (exact != null) {
            load(exact)?.let { return it }
        }
        val variable = mine.firstOrNull { it.contains('[') }
        if (variable != null) {
            loadVariable(variable, wght)?.let { return it }
        }
        val regular = mine.firstOrNull {
            it.substringBeforeLast('.').endsWith("-Regular", ignoreCase = true)
        } ?: mine.first()
        val base = load(regular) ?: return systemTypeface(wght)
        return if (wght >= 700) Typeface.create(base, Typeface.BOLD) else base
    }

    private fun load(file: String): Typeface? = try {
        Typeface.createFromAsset(context.assets, "fonts/$file")
    } catch (e: Exception) {
        null
    }

    private fun loadVariable(file: String, wght: Int): Typeface? = try {
        Typeface.Builder(context.assets, "fonts/$file")
            .setFontVariationSettings("'wght' $wght")
            .build()
    } catch (e: Exception) {
        null
    }

    private fun systemTypeface(wght: Int): Typeface =
        if (Build.VERSION.SDK_INT >= 28) {
            Typeface.create(Typeface.DEFAULT, wght, false)
        } else {
            Typeface.create(Typeface.DEFAULT, if (wght >= 700) Typeface.BOLD else Typeface.NORMAL)
        }
}
